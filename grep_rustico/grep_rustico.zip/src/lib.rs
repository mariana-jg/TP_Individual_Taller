pub mod regex;

pub mod caracter;

pub mod repeticion;

pub mod clase_char;

pub mod paso_regex;

pub mod paso_evaluado;

pub mod errors;

pub mod verificacion_inicial;
